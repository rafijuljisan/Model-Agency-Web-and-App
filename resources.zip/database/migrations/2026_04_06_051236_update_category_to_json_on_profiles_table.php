<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('profiles', function (Blueprint $table) {
            // Rename old column and add new JSON column
            $table->renameColumn('category', 'old_category');
            $table->json('categories')->nullable()->after('user_id');
        });
    }

    public function down(): void
    {
        Schema::table('profiles', function (Blueprint $table) {
            $table->dropColumn('categories');
            $table->renameColumn('old_category', 'category');
        });
    }
};
