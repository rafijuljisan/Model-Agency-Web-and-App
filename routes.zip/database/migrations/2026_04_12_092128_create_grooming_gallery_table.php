<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
{
    Schema::create('grooming_gallery', function (Blueprint $table) {
        $table->id();
        $table->string('title')->nullable();
        $table->string('image');
        $table->enum('category', ['training', 'graduation', 'event'])->default('training');
        $table->foreignId('batch_id')->nullable()->constrained('grooming_batches')->nullOnDelete();
        $table->boolean('is_featured')->default(false);
        $table->unsignedInteger('sort_order')->default(0);
        $table->timestamps();
    });
}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('grooming_gallery');
    }
};
